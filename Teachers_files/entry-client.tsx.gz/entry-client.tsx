import { createHotContext as __vite__createHotContext } from "/_build/@vite/client";import.meta.hot = __vite__createHotContext("/Users/jp/Documents/yogaOnyx/website/Yoga Onyx Web/src/entry-client.tsx");import { createComponent as _$createComponent } from "/_build/node_modules/.vinxi/client/deps/solid-js_web.js?v=ff703938";
import { $$decline as _$$decline } from "/_build/@solid-refresh";
import { mount, StartClient } from "/_build/node_modules/@solidjs/start/dist/client/index.jsx?t=1719976314600";
mount(() => _$createComponent(StartClient, {}), document.getElementById("app"));
if (import.meta.hot) {
  _$$decline("vite", import.meta.hot);
  import.meta.hot.accept();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7QUFDQSxTQUFTQSxPQUFPQyxtQkFBbUI7QUFFbkNELE1BQU0sTUFBQUUsa0JBQU9ELGFBQVcsS0FBS0UsU0FBU0MsZUFBZSxLQUFLLENBQUU7QUFBRSxJQUFBQyxZQUFBQyxLQUFBO0FBQUFDLGFBQUEsUUFBQUYsWUFBQUMsR0FBQTtBQUFBRCxjQUFBQyxJQUFBRSxPQUFBO0FBQUEiLCJuYW1lcyI6WyJtb3VudCIsIlN0YXJ0Q2xpZW50IiwiXyRjcmVhdGVDb21wb25lbnQiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwiaW1wb3J0IiwiaG90IiwiXyQkZGVjbGluZSIsImFjY2VwdCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJlbnRyeS1jbGllbnQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIEByZWZyZXNoIHJlbG9hZFxuaW1wb3J0IHsgbW91bnQsIFN0YXJ0Q2xpZW50IH0gZnJvbSBcIkBzb2xpZGpzL3N0YXJ0L2NsaWVudFwiO1xuXG5tb3VudCgoKSA9PiA8U3RhcnRDbGllbnQgLz4sIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiYXBwXCIpISk7XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qcC9Eb2N1bWVudHMveW9nYU9ueXgvd2Vic2l0ZS9Zb2dhIE9ueXggV2ViL3NyYy9lbnRyeS1jbGllbnQudHN4In0=